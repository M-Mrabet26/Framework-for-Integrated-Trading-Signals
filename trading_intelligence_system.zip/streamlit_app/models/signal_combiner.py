"""
Signal combiner and position sizing module.
Combines signals from all four layers and applies Kelly Criterion for position sizing.
"""

from typing import Dict, Tuple
from dataclasses import dataclass
import math
from streamlit_app.core.state_manager import (
    MacroState, FundamentalState, SentimentState, MicroState,
    MacroRegime, SentimentRegime, TradingMode
)
from streamlit_app.utils.logger import setup_logger

logger = setup_logger(__name__)


@dataclass
class SignalWeights:
    """Weights for combining signals from different layers."""
    macro_weight: float = 0.25
    fundamental_weight: float = 0.20
    sentiment_weight: float = 0.25
    micro_weight: float = 0.30


class SignalCombiner:
    """
    Combines signals from all four analytical layers.
    Implements regime-switching logic and Kelly Criterion position sizing.
    """
    
    def __init__(self, weights: SignalWeights = None):
        """
        Initialize the signal combiner.
        
        Args:
            weights: SignalWeights object with layer weights
        """
        self.weights = weights or SignalWeights()
        self.kelly_fraction = 0.25  # Fractional Kelly for risk control
        self.min_win_probability = 0.51  # Minimum win probability for trading
    
    def combine_signals(
        self,
        macro_state: MacroState,
        fundamental_state: FundamentalState,
        sentiment_state: SentimentState,
        micro_state: MicroState
    ) -> Tuple[float, float]:
        """
        Combine signals from all four layers.
        
        Args:
            macro_state: Current macro state
            fundamental_state: Current fundamental state
            sentiment_state: Current sentiment state
            micro_state: Current micro state
        
        Returns:
            Tuple of (combined_signal, confidence)
            Signal ranges from -1 (strong sell) to 1 (strong buy)
        """
        try:
            # Extract signal components from each layer
            macro_signal = self._extract_macro_signal(macro_state)
            fundamental_signal = self._extract_fundamental_signal(fundamental_state)
            sentiment_signal = self._extract_sentiment_signal(sentiment_state)
            micro_signal = self._extract_micro_signal(micro_state)
            
            # Adjust weights based on regime
            adjusted_weights = self._adjust_weights_by_regime(
                macro_state.regime, sentiment_state.regime
            )
            
            # Combine signals with adjusted weights
            combined_signal = (
                macro_signal * adjusted_weights['macro'] +
                fundamental_signal * adjusted_weights['fundamental'] +
                sentiment_signal * adjusted_weights['sentiment'] +
                micro_signal * adjusted_weights['micro']
            )
            
            # Calculate confidence based on signal agreement
            confidence = self._calculate_confidence(
                macro_signal, fundamental_signal, sentiment_signal, micro_signal
            )
            
            logger.info(f"Combined signal: {combined_signal:.3f} (confidence: {confidence:.2f})")
            return combined_signal, confidence
        
        except Exception as e:
            logger.error(f"Error combining signals: {e}")
            return 0.0, 0.0
    
    def _extract_macro_signal(self, macro_state: MacroState) -> float:
        """Extract trading signal from macro state."""
        # Map macro regime to signal
        regime_signals = {
            MacroRegime.RISK_ON: 0.5,
            MacroRegime.RISK_OFF: -0.5,
            MacroRegime.GROWTH: 0.7,
            MacroRegime.INFLATIONARY: -0.3,
            MacroRegime.STRESS: -0.8,
            MacroRegime.UNKNOWN: 0.0,
        }
        
        signal = regime_signals.get(macro_state.regime, 0.0)
        
        # Adjust based on confidence
        signal *= macro_state.confidence
        
        return signal
    
    def _extract_fundamental_signal(self, fundamental_state: FundamentalState) -> float:
        """Extract trading signal from fundamental state."""
        if fundamental_state.selected_ticker is None:
            return 0.0
        
        # Combine fundamental factor scores
        # Value and Quality are positive signals, Growth is context-dependent
        signal = (
            fundamental_state.value_score * 0.4 +
            fundamental_state.quality_score * 0.4 +
            (fundamental_state.growth_score - 0.5) * 0.2  # Neutral at 0.5
        )
        
        # Normalize to -1 to 1 range
        signal = (signal - 0.5) * 2
        
        return signal
    
    def _extract_sentiment_signal(self, sentiment_state: SentimentState) -> float:
        """Extract trading signal from sentiment state."""
        # Map sentiment regime to signal
        regime_signals = {
            SentimentRegime.EUPHORIA: 0.8,
            SentimentRegime.CONFIDENCE: 0.4,
            SentimentRegime.NEUTRAL: 0.0,
            SentimentRegime.FEAR: -0.4,
            SentimentRegime.PANIC: -0.8,
            SentimentRegime.UNKNOWN: 0.0,
        }
        
        signal = regime_signals.get(sentiment_state.regime, 0.0)
        
        # Adjust based on confidence
        signal *= sentiment_state.confidence
        
        return signal
    
    def _extract_micro_signal(self, micro_state: MicroState) -> float:
        """Extract trading signal from microstructure state."""
        # Combine technical signals
        rsi_signal = (micro_state.rsi - 50) / 50  # Normalize RSI to -1 to 1
        
        # Momentum vs Mean Reversion selection
        if micro_state.trading_mode == TradingMode.MOMENTUM:
            momentum_signal = micro_state.momentum_signal
        elif micro_state.trading_mode == TradingMode.MEAN_REVERSION:
            momentum_signal = -micro_state.mean_reversion_signal
        else:
            momentum_signal = 0.0
        
        # Combine signals
        signal = (
            rsi_signal * 0.3 +
            momentum_signal * 0.4 +
            micro_state.breakout_signal * 0.3
        )
        
        # Adjust based on confidence
        signal *= micro_state.confidence
        
        return signal
    
    def _adjust_weights_by_regime(
        self,
        macro_regime: MacroRegime,
        sentiment_regime: SentimentRegime
    ) -> Dict[str, float]:
        """
        Adjust signal weights based on macro and sentiment regimes.
        
        Returns:
            Dictionary with adjusted weights (sum to 1.0)
        """
        weights = {
            'macro': self.weights.macro_weight,
            'fundamental': self.weights.fundamental_weight,
            'sentiment': self.weights.sentiment_weight,
            'micro': self.weights.micro_weight,
        }
        
        # In stress regimes, increase macro weight
        if macro_regime == MacroRegime.STRESS:
            weights['macro'] *= 1.5
            weights['micro'] *= 0.7
        
        # In growth regimes, increase fundamental weight
        elif macro_regime == MacroRegime.GROWTH:
            weights['fundamental'] *= 1.3
            weights['macro'] *= 0.8
        
        # In high volatility (fear/panic), increase sentiment weight
        if sentiment_regime in [SentimentRegime.FEAR, SentimentRegime.PANIC]:
            weights['sentiment'] *= 1.4
            weights['fundamental'] *= 0.7
        
        # Normalize weights to sum to 1.0
        total = sum(weights.values())
        weights = {k: v / total for k, v in weights.items()}
        
        return weights
    
    def _calculate_confidence(
        self,
        macro_signal: float,
        fundamental_signal: float,
        sentiment_signal: float,
        micro_signal: float
    ) -> float:
        """
        Calculate confidence based on signal agreement.
        Higher confidence when signals align.
        """
        signals = [macro_signal, fundamental_signal, sentiment_signal, micro_signal]
        
        # Calculate standard deviation of signals
        mean_signal = sum(signals) / len(signals)
        variance = sum((s - mean_signal) ** 2 for s in signals) / len(signals)
        std_dev = math.sqrt(variance)
        
        # Confidence is inverse of std dev (high agreement = high confidence)
        # Normalize to 0-1 range
        confidence = max(0.0, 1.0 - std_dev)
        
        return confidence
    
    def calculate_kelly_position_size(
        self,
        combined_signal: float,
        signal_confidence: float,
        win_probability: float = None,
        payoff_ratio: float = None
    ) -> float:
        """
        Calculate optimal position size using Kelly Criterion.
        
        Args:
            combined_signal: Combined trading signal (-1 to 1)
            signal_confidence: Confidence in the signal (0 to 1)
            win_probability: Historical win probability (optional)
            payoff_ratio: Win/loss ratio (optional)
        
        Returns:
            Recommended position size (0 to 1)
        """
        try:
            # If win probability and payoff ratio provided, use them
            if win_probability is not None and payoff_ratio is not None:
                # Kelly formula: f* = (bp - q) / b
                # where b = payoff_ratio, p = win_probability, q = 1 - p
                if payoff_ratio > 0:
                    kelly_fraction = (payoff_ratio * win_probability - (1 - win_probability)) / payoff_ratio
                    kelly_fraction = max(0.0, min(1.0, kelly_fraction))  # Clamp to 0-1
                else:
                    kelly_fraction = 0.0
            else:
                # Use signal-based approach
                # Map signal to win probability
                win_probability = 0.5 + (combined_signal * 0.3)  # Signal contributes up to 30% to win prob
                win_probability = max(self.min_win_probability, min(1.0, win_probability))
                
                # Assume payoff ratio of 1.0 (equal risk/reward)
                payoff_ratio = 1.0
                
                # Kelly formula
                kelly_fraction = (payoff_ratio * win_probability - (1 - win_probability)) / payoff_ratio
                kelly_fraction = max(0.0, min(1.0, kelly_fraction))
            
            # Apply fractional Kelly for risk control
            position_size = kelly_fraction * self.kelly_fraction * signal_confidence
            
            logger.info(f"Kelly position size: {position_size:.3f} (win_prob: {win_probability:.2f})")
            return position_size
        
        except Exception as e:
            logger.error(f"Error calculating Kelly position size: {e}")
            return 0.0


# Global signal combiner instance
_signal_combiner: SignalCombiner = None


def get_signal_combiner() -> SignalCombiner:
    """Get or create the global signal combiner instance."""
    global _signal_combiner
    if _signal_combiner is None:
        _signal_combiner = SignalCombiner()
    return _signal_combiner
