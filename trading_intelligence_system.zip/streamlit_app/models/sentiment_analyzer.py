"""
Sentiment analyzer module.
Performs NLP-based sentiment analysis on news and market data.
"""

from typing import Dict, Tuple, List
from dataclasses import dataclass
import re
from streamlit_app.core.state_manager import SentimentRegime
from streamlit_app.utils.logger import setup_logger

logger = setup_logger(__name__)

# Try to import NLTK for sentiment analysis
try:
    from nltk.sentiment import SentimentIntensityAnalyzer
    nltk_available = True
except ImportError:
    nltk_available = False
    logger.warning("NLTK not available. Using basic sentiment analysis.")


@dataclass
class NewsItem:
    """Container for a news item."""
    title: str
    content: str
    source: str
    timestamp: str
    sentiment_score: float = 0.0


class SentimentAnalyzer:
    """
    Sentiment analyzer using VADER (Valence Aware Dictionary and sEntiment Reasoner).
    Provides both overall market sentiment and entity-specific sentiment.
    """
    
    def __init__(self):
        """Initialize the sentiment analyzer."""
        if nltk_available:
            try:
                self.sia = SentimentIntensityAnalyzer()
            except Exception as e:
                logger.warning(f"Failed to initialize VADER: {e}")
                self.sia = None
        else:
            self.sia = None
        
        # Basic sentiment keywords for fallback analysis
        self.positive_keywords = [
            "bullish", "rally", "surge", "gain", "profit", "growth", "strong",
            "outperform", "upgrade", "beat", "positive", "excellent", "soar"
        ]
        self.negative_keywords = [
            "bearish", "crash", "plunge", "loss", "decline", "weak", "downgrade",
            "miss", "negative", "poor", "sell-off", "tumble", "collapse"
        ]
    
    def analyze_text(self, text: str) -> float:
        """
        Analyze sentiment of text.
        
        Args:
            text: Text to analyze
        
        Returns:
            Sentiment score (-1 to 1, where -1 is very negative, 1 is very positive)
        """
        if not text:
            return 0.0
        
        try:
            text_lower = text.lower()
            
            # Use VADER if available
            if self.sia:
                scores = self.sia.polarity_scores(text_lower)
                return scores['compound']  # Range: -1 to 1
            else:
                # Fallback: basic keyword-based sentiment
                positive_count = sum(1 for keyword in self.positive_keywords if keyword in text_lower)
                negative_count = sum(1 for keyword in self.negative_keywords if keyword in text_lower)
                
                if positive_count + negative_count == 0:
                    return 0.0
                
                return (positive_count - negative_count) / (positive_count + negative_count)
        
        except Exception as e:
            logger.error(f"Error analyzing sentiment: {e}")
            return 0.0
    
    def analyze_news(self, news_items: List[NewsItem]) -> Tuple[float, Dict[str, float]]:
        """
        Analyze sentiment across multiple news items.
        
        Args:
            news_items: List of NewsItem objects
        
        Returns:
            Tuple of (overall_sentiment, entity_sentiments)
        """
        if not news_items:
            return 0.0, {}
        
        try:
            # Analyze each news item
            sentiments = []
            entity_sentiments: Dict[str, float] = {}
            
            for item in news_items:
                # Analyze title and content
                title_sentiment = self.analyze_text(item.title)
                content_sentiment = self.analyze_text(item.content)
                
                # Weight title more heavily
                item_sentiment = title_sentiment * 0.6 + content_sentiment * 0.4
                sentiments.append(item_sentiment)
                
                # Extract entities (simple approach: look for company names/tickers)
                entities = self._extract_entities(item.title + " " + item.content)
                for entity in entities:
                    if entity not in entity_sentiments:
                        entity_sentiments[entity] = []
                    entity_sentiments[entity].append(item_sentiment)
            
            # Calculate averages
            overall_sentiment = sum(sentiments) / len(sentiments) if sentiments else 0.0
            
            # Average entity sentiments
            entity_sentiments = {
                entity: sum(scores) / len(scores)
                for entity, scores in entity_sentiments.items()
            }
            
            return overall_sentiment, entity_sentiments
        
        except Exception as e:
            logger.error(f"Error analyzing news: {e}")
            return 0.0, {}
    
    def _extract_entities(self, text: str) -> List[str]:
        """
        Extract potential entities (companies, tickers) from text.
        Simple implementation: looks for capitalized words and common tickers.
        
        Args:
            text: Text to extract entities from
        
        Returns:
            List of potential entities
        """
        try:
            # Find capitalized words (potential company names)
            entities = re.findall(r'\b[A-Z][A-Z]+\b', text)
            
            # Filter out common words
            common_words = {'THE', 'AND', 'FOR', 'WITH', 'FROM', 'THAT', 'THIS', 'WHICH', 'WILL'}
            entities = [e for e in entities if e not in common_words and len(e) <= 5]
            
            return list(set(entities))  # Remove duplicates
        
        except Exception as e:
            logger.error(f"Error extracting entities: {e}")
            return []
    
    def classify_sentiment_regime(self, sentiment_score: float) -> Tuple[SentimentRegime, float]:
        """
        Classify sentiment regime based on sentiment score.
        
        Args:
            sentiment_score: Overall sentiment score (-1 to 1)
        
        Returns:
            Tuple of (regime, confidence)
        """
        try:
            # Map sentiment score to regime
            if sentiment_score > 0.5:
                regime = SentimentRegime.EUPHORIA
                confidence = min(sentiment_score, 1.0)
            elif sentiment_score > 0.25:
                regime = SentimentRegime.CONFIDENCE
                confidence = sentiment_score
            elif sentiment_score > -0.25:
                regime = SentimentRegime.NEUTRAL
                confidence = 1.0 - abs(sentiment_score)
            elif sentiment_score > -0.5:
                regime = SentimentRegime.FEAR
                confidence = abs(sentiment_score)
            else:
                regime = SentimentRegime.PANIC
                confidence = min(abs(sentiment_score), 1.0)
            
            return regime, confidence
        
        except Exception as e:
            logger.error(f"Error classifying sentiment regime: {e}")
            return SentimentRegime.UNKNOWN, 0.0


# Global analyzer instance
_sentiment_analyzer: SentimentAnalyzer = None


def get_sentiment_analyzer() -> SentimentAnalyzer:
    """Get or create the global sentiment analyzer instance."""
    global _sentiment_analyzer
    if _sentiment_analyzer is None:
        _sentiment_analyzer = SentimentAnalyzer()
    return _sentiment_analyzer
