"""
Technical analysis module.
Calculates technical indicators and generates microstructure signals.
"""

from typing import List, Tuple, Optional
from dataclasses import dataclass
import numpy as np
from streamlit_app.core.state_manager import TradingMode
from streamlit_app.utils.logger import setup_logger

logger = setup_logger(__name__)


@dataclass
class PriceData:
    """Container for price data."""
    timestamp: str
    open: float
    high: float
    low: float
    close: float
    volume: int


class TechnicalAnalyzer:
    """
    Technical analysis engine.
    Calculates indicators and generates trading signals.
    """
    
    def __init__(self):
        """Initialize the technical analyzer."""
        self.rsi_period = 14
        self.ma_short_period = 20
        self.ma_long_period = 50
        self.atr_period = 14
        self.macd_fast = 12
        self.macd_slow = 26
        self.macd_signal = 9
    
    def calculate_rsi(self, prices: List[float], period: int = 14) -> float:
        """
        Calculate Relative Strength Index (RSI).
        
        Args:
            prices: List of closing prices
            period: RSI period (default: 14)
        
        Returns:
            RSI value (0-100)
        """
        try:
            if len(prices) < period + 1:
                return 50.0  # Neutral
            
            prices = prices[-period-1:]
            deltas = np.diff(prices)
            
            gains = np.where(deltas > 0, deltas, 0)
            losses = np.where(deltas < 0, -deltas, 0)
            
            avg_gain = np.mean(gains)
            avg_loss = np.mean(losses)
            
            if avg_loss == 0:
                return 100.0 if avg_gain > 0 else 50.0
            
            rs = avg_gain / avg_loss
            rsi = 100 - (100 / (1 + rs))
            
            return float(rsi)
        
        except Exception as e:
            logger.error(f"Error calculating RSI: {e}")
            return 50.0
    
    def calculate_moving_average(self, prices: List[float], period: int) -> float:
        """
        Calculate Simple Moving Average (SMA).
        
        Args:
            prices: List of prices
            period: MA period
        
        Returns:
            MA value
        """
        try:
            if len(prices) < period:
                return prices[-1] if prices else 0.0
            
            return float(np.mean(prices[-period:]))
        
        except Exception as e:
            logger.error(f"Error calculating MA: {e}")
            return 0.0
    
    def calculate_atr(self, high_prices: List[float], low_prices: List[float], 
                     close_prices: List[float], period: int = 14) -> float:
        """
        Calculate Average True Range (ATR).
        
        Args:
            high_prices: List of high prices
            low_prices: List of low prices
            close_prices: List of close prices
            period: ATR period
        
        Returns:
            ATR value
        """
        try:
            if len(high_prices) < period:
                return 0.0
            
            # Calculate true ranges
            tr_list = []
            for i in range(len(high_prices)):
                if i == 0:
                    tr = high_prices[i] - low_prices[i]
                else:
                    tr1 = high_prices[i] - low_prices[i]
                    tr2 = abs(high_prices[i] - close_prices[i-1])
                    tr3 = abs(low_prices[i] - close_prices[i-1])
                    tr = max(tr1, tr2, tr3)
                tr_list.append(tr)
            
            # Calculate ATR
            atr = np.mean(tr_list[-period:])
            return float(atr)
        
        except Exception as e:
            logger.error(f"Error calculating ATR: {e}")
            return 0.0
    
    def calculate_volatility(self, prices: List[float], period: int = 20) -> float:
        """
        Calculate historical volatility (standard deviation).
        
        Args:
            prices: List of prices
            period: Lookback period
        
        Returns:
            Volatility as percentage
        """
        try:
            if len(prices) < period:
                return 0.0
            
            returns = np.diff(prices[-period:]) / prices[-period:-1]
            volatility = np.std(returns) * 100  # Convert to percentage
            
            return float(volatility)
        
        except Exception as e:
            logger.error(f"Error calculating volatility: {e}")
            return 0.0
    
    def detect_breakout(self, prices: List[float], lookback: int = 20) -> float:
        """
        Detect breakout signal.
        
        Args:
            prices: List of prices
            lookback: Lookback period for resistance/support
        
        Returns:
            Breakout signal (-1 to 1)
        """
        try:
            if len(prices) < lookback + 1:
                return 0.0
            
            recent_prices = prices[-lookback:]
            resistance = max(recent_prices)
            support = min(recent_prices)
            current_price = prices[-1]
            
            # Calculate breakout strength
            if current_price > resistance:
                breakout_signal = min(1.0, (current_price - resistance) / (resistance - support + 1e-6))
            elif current_price < support:
                breakout_signal = max(-1.0, (current_price - support) / (resistance - support + 1e-6))
            else:
                breakout_signal = 0.0
            
            return float(breakout_signal)
        
        except Exception as e:
            logger.error(f"Error detecting breakout: {e}")
            return 0.0
    
    def detect_mean_reversion(self, prices: List[float], period: int = 20) -> float:
        """
        Detect mean reversion signal.
        
        Args:
            prices: List of prices
            period: MA period
        
        Returns:
            Mean reversion signal (-1 to 1)
        """
        try:
            if len(prices) < period:
                return 0.0
            
            ma = self.calculate_moving_average(prices, period)
            current_price = prices[-1]
            
            # Calculate deviation from MA
            if ma > 0:
                deviation = (current_price - ma) / ma
                # Normalize to -1 to 1 range
                mean_reversion_signal = max(-1.0, min(1.0, deviation * 2))
            else:
                mean_reversion_signal = 0.0
            
            return float(mean_reversion_signal)
        
        except Exception as e:
            logger.error(f"Error detecting mean reversion: {e}")
            return 0.0
    
    def detect_momentum(self, prices: List[float], period: int = 14) -> float:
        """
        Detect momentum signal using price rate of change.
        
        Args:
            prices: List of prices
            period: Momentum period
        
        Returns:
            Momentum signal (-1 to 1)
        """
        try:
            if len(prices) < period + 1:
                return 0.0
            
            current_price = prices[-1]
            past_price = prices[-period-1]
            
            if past_price > 0:
                momentum = (current_price - past_price) / past_price
                # Normalize to -1 to 1 range
                momentum_signal = max(-1.0, min(1.0, momentum * 2))
            else:
                momentum_signal = 0.0
            
            return float(momentum_signal)
        
        except Exception as e:
            logger.error(f"Error detecting momentum: {e}")
            return 0.0
    
    def select_trading_mode(self, prices: List[float], volatility: float) -> Tuple[TradingMode, float]:
        """
        Select trading mode based on market conditions.
        
        Args:
            prices: List of prices
            volatility: Current volatility
        
        Returns:
            Tuple of (trading_mode, confidence)
        """
        try:
            if len(prices) < 50:
                return TradingMode.UNKNOWN, 0.0
            
            # Calculate indicators
            momentum = self.detect_momentum(prices)
            mean_reversion = self.detect_mean_reversion(prices)
            rsi = self.calculate_rsi(prices)
            
            # Determine trading mode
            if volatility > 3.0:  # High volatility
                if rsi > 70 or rsi < 30:
                    mode = TradingMode.MEAN_REVERSION
                    confidence = 0.7
                else:
                    mode = TradingMode.MOMENTUM
                    confidence = 0.6
            else:  # Low volatility
                if abs(momentum) > 0.02:
                    mode = TradingMode.MOMENTUM
                    confidence = 0.7
                else:
                    mode = TradingMode.RANGE_BOUND
                    confidence = 0.6
            
            return mode, confidence
        
        except Exception as e:
            logger.error(f"Error selecting trading mode: {e}")
            return TradingMode.UNKNOWN, 0.0


# Global analyzer instance
_technical_analyzer: TechnicalAnalyzer = None


def get_technical_analyzer() -> TechnicalAnalyzer:
    """Get or create the global technical analyzer instance."""
    global _technical_analyzer
    if _technical_analyzer is None:
        _technical_analyzer = TechnicalAnalyzer()
    return _technical_analyzer
