"""
Macro regime classifier module.
Classifies macroeconomic regimes based on key indicators.
"""

from typing import Dict, Tuple
from dataclasses import dataclass
import numpy as np
from streamlit_app.core.state_manager import MacroRegime
from streamlit_app.utils.logger import setup_logger

logger = setup_logger(__name__)


@dataclass
class MacroIndicators:
    """Container for macro indicators."""
    interest_rate: float
    yield_curve_slope: float
    inflation_rate: float
    volatility_index: float
    liquidity_score: float
    gdp_growth: float = 0.0
    unemployment_rate: float = 0.0


class MacroRegimeClassifier:
    """
    Rule-based macro regime classifier (MVP).
    Classifies market regime based on macroeconomic indicators.
    """
    
    def __init__(self):
        """Initialize the classifier with default thresholds."""
        # Thresholds for regime classification
        self.rate_threshold_high = 3.0  # %
        self.rate_threshold_low = 1.0  # %
        self.yield_curve_threshold = 0.5  # %
        self.inflation_threshold_high = 3.0  # %
        self.inflation_threshold_low = 1.5  # %
        self.vix_threshold_high = 25.0
        self.vix_threshold_low = 15.0
    
    def classify(self, indicators: MacroIndicators) -> Tuple[MacroRegime, float]:
        """
        Classify the macro regime based on indicators.
        
        Args:
            indicators: MacroIndicators object with current values
        
        Returns:
            Tuple of (regime, confidence)
        """
        try:
            # Normalize indicators to scores (0-1)
            rate_score = self._normalize_rate(indicators.interest_rate)
            yield_score = self._normalize_yield_curve(indicators.yield_curve_slope)
            inflation_score = self._normalize_inflation(indicators.inflation_rate)
            volatility_score = self._normalize_volatility(indicators.volatility_index)
            liquidity_score = indicators.liquidity_score  # Already normalized
            
            # Regime decision logic
            regime, confidence = self._determine_regime(
                rate_score, yield_score, inflation_score, volatility_score, liquidity_score
            )
            
            logger.info(f"Classified regime: {regime.value} (confidence: {confidence:.2f})")
            return regime, confidence
        
        except Exception as e:
            logger.error(f"Error classifying regime: {e}")
            return MacroRegime.UNKNOWN, 0.0
    
    def _normalize_rate(self, rate: float) -> float:
        """Normalize interest rate to 0-1 score."""
        if rate < self.rate_threshold_low:
            return 0.0
        elif rate > self.rate_threshold_high:
            return 1.0
        else:
            return (rate - self.rate_threshold_low) / (self.rate_threshold_high - self.rate_threshold_low)
    
    def _normalize_yield_curve(self, slope: float) -> float:
        """Normalize yield curve slope to 0-1 score."""
        # Positive slope = normal (0.5+), negative = inverted (0.0-0.5)
        if slope < -self.yield_curve_threshold:
            return 0.0  # Inverted
        elif slope > self.yield_curve_threshold:
            return 1.0  # Steep
        else:
            return 0.5 + (slope / (2 * self.yield_curve_threshold))
    
    def _normalize_inflation(self, inflation: float) -> float:
        """Normalize inflation rate to 0-1 score."""
        if inflation < self.inflation_threshold_low:
            return 0.0  # Low inflation
        elif inflation > self.inflation_threshold_high:
            return 1.0  # High inflation
        else:
            return (inflation - self.inflation_threshold_low) / (self.inflation_threshold_high - self.inflation_threshold_low)
    
    def _normalize_volatility(self, vix: float) -> float:
        """Normalize VIX to 0-1 score."""
        if vix < self.vix_threshold_low:
            return 0.0  # Low volatility
        elif vix > self.vix_threshold_high:
            return 1.0  # High volatility
        else:
            return (vix - self.vix_threshold_low) / (self.vix_threshold_high - self.vix_threshold_low)
    
    def _determine_regime(
        self,
        rate_score: float,
        yield_score: float,
        inflation_score: float,
        volatility_score: float,
        liquidity_score: float
    ) -> Tuple[MacroRegime, float]:
        """
        Determine regime based on normalized indicator scores.
        
        Returns:
            Tuple of (regime, confidence)
        """
        # Calculate composite scores for different regimes
        risk_on_score = (
            (1 - volatility_score) * 0.4 +  # Low volatility
            liquidity_score * 0.3 +  # High liquidity
            yield_score * 0.3  # Steep yield curve
        )
        
        risk_off_score = (
            volatility_score * 0.5 +  # High volatility
            (1 - liquidity_score) * 0.3 +  # Low liquidity
            (1 - yield_score) * 0.2  # Flat/inverted yield curve
        )
        
        growth_score = (
            rate_score * 0.3 +  # Rising rates
            yield_score * 0.3 +  # Steep yield curve
            (1 - inflation_score) * 0.2 +  # Moderate inflation
            (1 - volatility_score) * 0.2  # Low volatility
        )
        
        inflationary_score = (
            inflation_score * 0.4 +  # High inflation
            rate_score * 0.3 +  # Rising rates
            volatility_score * 0.2 +  # Elevated volatility
            (1 - liquidity_score) * 0.1  # Tight liquidity
        )
        
        stress_score = (
            volatility_score * 0.4 +  # Very high volatility
            (1 - liquidity_score) * 0.4 +  # Very low liquidity
            (1 - yield_score) * 0.2  # Inverted yield curve
        )
        
        # Determine regime based on highest score
        scores = {
            MacroRegime.RISK_ON: risk_on_score,
            MacroRegime.RISK_OFF: risk_off_score,
            MacroRegime.GROWTH: growth_score,
            MacroRegime.INFLATIONARY: inflationary_score,
            MacroRegime.STRESS: stress_score,
        }
        
        regime = max(scores, key=scores.get)
        confidence = scores[regime]
        
        return regime, confidence
    
    def get_regime_description(self, regime: MacroRegime) -> str:
        """Get a description of the regime."""
        descriptions = {
            MacroRegime.RISK_ON: "Favorable market conditions with low volatility and strong liquidity. Investors are risk-seeking.",
            MacroRegime.RISK_OFF: "Elevated uncertainty and volatility. Investors are risk-averse and seeking safe havens.",
            MacroRegime.GROWTH: "Economic expansion with rising rates and steep yield curve. Growth assets favored.",
            MacroRegime.INFLATIONARY: "High inflation environment with rising rates. Real assets and commodities favored.",
            MacroRegime.STRESS: "Market stress with very high volatility and liquidity constraints. Flight to quality.",
            MacroRegime.UNKNOWN: "Insufficient data to classify regime.",
        }
        return descriptions.get(regime, "Unknown regime")


# Global classifier instance
_macro_classifier: MacroRegimeClassifier = None


def get_macro_classifier() -> MacroRegimeClassifier:
    """Get or create the global macro classifier instance."""
    global _macro_classifier
    if _macro_classifier is None:
        _macro_classifier = MacroRegimeClassifier()
    return _macro_classifier
