"""
Trading Intelligence System - Streamlit Application Package
"""

__version__ = "0.1.0"
__author__ = "Trading Intelligence Team"

from streamlit_app.config import (
    ib_config,
    data_config,
    model_config,
    dashboard_config,
    logging_config,
    get_config_summary,
)

__all__ = [
    "ib_config",
    "data_config",
    "model_config",
    "dashboard_config",
    "logging_config",
    "get_config_summary",
]
