"""
State management module for the Trading Intelligence System.
Manages shared state across dashboards and provides centralized data access.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from datetime import datetime
from enum import Enum
import streamlit as st


class MacroRegime(Enum):
    """Macro regime classification."""
    RISK_ON = "Risk-On"
    RISK_OFF = "Risk-Off"
    GROWTH = "Growth"
    INFLATIONARY = "Inflationary"
    STRESS = "Stress"
    UNKNOWN = "Unknown"


class SentimentRegime(Enum):
    """Sentiment/emotional regime classification."""
    EUPHORIA = "Euphoria"
    CONFIDENCE = "Confidence"
    NEUTRAL = "Neutral"
    FEAR = "Fear"
    PANIC = "Panic"
    UNKNOWN = "Unknown"


class TradingMode(Enum):
    """Trading mode selection."""
    MOMENTUM = "Momentum"
    MEAN_REVERSION = "Mean Reversion"
    BREAKOUT = "Breakout"
    RANGE_BOUND = "Range Bound"
    UNKNOWN = "Unknown"


@dataclass
class MacroState:
    """State for macro analysis."""
    regime: MacroRegime = MacroRegime.UNKNOWN
    interest_rate: float = 0.0
    yield_curve_slope: float = 0.0
    inflation_rate: float = 0.0
    volatility_index: float = 0.0
    liquidity_score: float = 0.5
    confidence: float = 0.0
    last_updated: datetime = field(default_factory=datetime.now)


@dataclass
class FundamentalState:
    """State for fundamental analysis."""
    selected_ticker: Optional[str] = None
    market_cap: float = 0.0
    revenue: float = 0.0
    earnings_per_share: float = 0.0
    price_to_earnings: float = 0.0
    value_score: float = 0.0
    quality_score: float = 0.0
    growth_score: float = 0.0
    analyst_rating: float = 0.0
    last_updated: datetime = field(default_factory=datetime.now)


@dataclass
class SentimentState:
    """State for sentiment analysis."""
    regime: SentimentRegime = SentimentRegime.UNKNOWN
    overall_score: float = 0.0
    news_sentiment: float = 0.0
    social_sentiment: float = 0.0
    entity_scores: Dict[str, float] = field(default_factory=dict)
    confidence: float = 0.0
    last_updated: datetime = field(default_factory=datetime.now)


@dataclass
class MicroState:
    """State for market microstructure analysis."""
    trading_mode: TradingMode = TradingMode.UNKNOWN
    rsi: float = 50.0
    moving_average_20: float = 0.0
    moving_average_50: float = 0.0
    volatility: float = 0.0
    volume_trend: float = 0.0
    breakout_signal: float = 0.0
    mean_reversion_signal: float = 0.0
    momentum_signal: float = 0.0
    confidence: float = 0.0
    last_updated: datetime = field(default_factory=datetime.now)


@dataclass
class SignalState:
    """State for combined trading signal."""
    final_signal: float = 0.0  # -1 to 1, where -1 is strong sell, 1 is strong buy
    signal_confidence: float = 0.0
    recommended_position_size: float = 0.0
    kelly_fraction: float = 0.25
    win_probability: float = 0.5
    payoff_ratio: float = 1.0
    last_updated: datetime = field(default_factory=datetime.now)


class StateManager:
    """
    Central state manager for the trading system.
    Manages all shared state across dashboards.
    """
    
    def __init__(self):
        """Initialize the state manager."""
        self.macro_state = MacroState()
        self.fundamental_state = FundamentalState()
        self.sentiment_state = SentimentState()
        self.micro_state = MicroState()
        self.signal_state = SignalState()
        self.selected_tickers: List[str] = []
        self.ib_connected: bool = False
        self.last_sync: datetime = datetime.now()
    
    def update_macro_state(self, regime: MacroRegime, **kwargs):
        """Update macro state."""
        self.macro_state.regime = regime
        for key, value in kwargs.items():
            if hasattr(self.macro_state, key):
                setattr(self.macro_state, key, value)
        self.macro_state.last_updated = datetime.now()
    
    def update_fundamental_state(self, ticker: str, **kwargs):
        """Update fundamental state."""
        self.fundamental_state.selected_ticker = ticker
        for key, value in kwargs.items():
            if hasattr(self.fundamental_state, key):
                setattr(self.fundamental_state, key, value)
        self.fundamental_state.last_updated = datetime.now()
    
    def update_sentiment_state(self, regime: SentimentRegime, **kwargs):
        """Update sentiment state."""
        self.sentiment_state.regime = regime
        for key, value in kwargs.items():
            if hasattr(self.sentiment_state, key):
                setattr(self.sentiment_state, key, value)
        self.sentiment_state.last_updated = datetime.now()
    
    def update_micro_state(self, trading_mode: TradingMode, **kwargs):
        """Update microstructure state."""
        self.micro_state.trading_mode = trading_mode
        for key, value in kwargs.items():
            if hasattr(self.micro_state, key):
                setattr(self.micro_state, key, value)
        self.micro_state.last_updated = datetime.now()
    
    def update_signal_state(self, **kwargs):
        """Update signal state."""
        for key, value in kwargs.items():
            if hasattr(self.signal_state, key):
                setattr(self.signal_state, key, value)
        self.signal_state.last_updated = datetime.now()
    
    def set_selected_tickers(self, tickers: List[str]):
        """Set the currently selected tickers."""
        self.selected_tickers = tickers
    
    def set_ib_connection_status(self, connected: bool):
        """Set IB connection status."""
        self.ib_connected = connected
    
    def get_summary(self) -> Dict[str, Any]:
        """Get a summary of all states."""
        return {
            "macro": {
                "regime": self.macro_state.regime.value,
                "volatility": self.macro_state.volatility_index,
                "confidence": self.macro_state.confidence,
            },
            "fundamental": {
                "ticker": self.fundamental_state.selected_ticker,
                "value_score": self.fundamental_state.value_score,
                "quality_score": self.fundamental_state.quality_score,
                "growth_score": self.fundamental_state.growth_score,
            },
            "sentiment": {
                "regime": self.sentiment_state.regime.value,
                "score": self.sentiment_state.overall_score,
                "confidence": self.sentiment_state.confidence,
            },
            "micro": {
                "trading_mode": self.micro_state.trading_mode.value,
                "rsi": self.micro_state.rsi,
                "volatility": self.micro_state.volatility,
            },
            "signal": {
                "final_signal": self.signal_state.final_signal,
                "confidence": self.signal_state.signal_confidence,
                "position_size": self.signal_state.recommended_position_size,
            },
            "ib_connected": self.ib_connected,
            "selected_tickers": self.selected_tickers,
        }


def get_state_manager() -> StateManager:
    """
    Get the global state manager instance using Streamlit session state.
    
    Returns:
        StateManager instance
    """
    if "state_manager" not in st.session_state:
        st.session_state.state_manager = StateManager()
    return st.session_state.state_manager
