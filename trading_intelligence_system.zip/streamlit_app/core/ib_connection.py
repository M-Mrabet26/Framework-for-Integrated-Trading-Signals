"""
Interactive Brokers API connection module.
Handles connection, data fetching, and streaming capabilities.
"""

import time
import threading
from typing import Optional, Dict, List, Callable, Any
from datetime import datetime, timedelta
from dataclasses import dataclass, field
import queue

try:
    from ibapi.client import EClient
    from ibapi.wrapper import EWrapper
    from ibapi.contract import Contract
    from ibapi.common import TickAttrib
except ImportError:
    EClient = None
    EWrapper = None
    Contract = None
    TickAttrib = None

from streamlit_app.config import ib_config
from streamlit_app.utils.logger import setup_logger

logger = setup_logger(__name__)


@dataclass
class TickData:
    """Container for tick data from IB."""
    symbol: str
    bid: float = 0.0
    ask: float = 0.0
    last: float = 0.0
    volume: int = 0
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class BarData:
    """Container for bar/candle data from IB."""
    symbol: str
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: int
    average: float
    count: int


class IBWrapper(EWrapper):
    """
    Wrapper class for Interactive Brokers API callbacks.
    Handles incoming market data and connection events.
    """
    
    def __init__(self):
        super().__init__()
        self.tick_data: Dict[int, TickData] = {}
        self.bar_data: Dict[int, List[BarData]] = {}
        self.contract_details: Dict[int, Dict] = {}
        self.next_valid_order_id: Optional[int] = None
        self.connection_status = "disconnected"
        
        # Queues for async data processing
        self.tick_queue: queue.Queue = queue.Queue()
        self.bar_queue: queue.Queue = queue.Queue()
        self.error_queue: queue.Queue = queue.Queue()
        
        # Callbacks
        self.callbacks: Dict[str, List[Callable]] = {
            "tick": [],
            "bar": [],
            "error": [],
            "connection": [],
        }
    
    def error(self, req_id: int, error_code: int, error_string: str, advancedOrderRejectJson: str = ""):
        """Handle error messages from IB."""
        error_msg = f"IB Error [{req_id}] {error_code}: {error_string}"
        logger.error(error_msg)
        self.error_queue.put((req_id, error_code, error_string))
        
        for callback in self.callbacks.get("error", []):
            try:
                callback(req_id, error_code, error_string)
            except Exception as e:
                logger.error(f"Error in callback: {e}")
    
    def connectionClosed(self):
        """Called when connection is closed."""
        logger.warning("IB Connection closed")
        self.connection_status = "disconnected"
        for callback in self.callbacks.get("connection", []):
            try:
                callback("disconnected")
            except Exception as e:
                logger.error(f"Error in connection callback: {e}")
    
    def nextValidId(self, order_id: int):
        """Called when connection is established."""
        self.next_valid_order_id = order_id
        self.connection_status = "connected"
        logger.info(f"IB Connected. Next valid order ID: {order_id}")
        for callback in self.callbacks.get("connection", []):
            try:
                callback("connected")
            except Exception as e:
                logger.error(f"Error in connection callback: {e}")
    
    def tickPrice(self, req_id: int, tick_type: int, price: float, attrib: TickAttrib):
        """Handle tick price updates."""
        if req_id not in self.tick_data:
            self.tick_data[req_id] = TickData(symbol=f"REQ_{req_id}")
        
        tick = self.tick_data[req_id]
        
        # Map tick types to data fields
        if tick_type == 1:  # BID
            tick.bid = price
        elif tick_type == 2:  # ASK
            tick.ask = price
        elif tick_type == 4:  # LAST
            tick.last = price
        
        tick.timestamp = datetime.now()
        self.tick_queue.put((req_id, tick))
        
        for callback in self.callbacks.get("tick", []):
            try:
                callback(req_id, tick)
            except Exception as e:
                logger.error(f"Error in tick callback: {e}")
    
    def tickSize(self, req_id: int, tick_type: int, size: int):
        """Handle tick size updates."""
        if req_id not in self.tick_data:
            self.tick_data[req_id] = TickData(symbol=f"REQ_{req_id}")
        
        tick = self.tick_data[req_id]
        
        if tick_type == 8:  # VOLUME
            tick.volume = size
        
        tick.timestamp = datetime.now()
    
    def historicalData(self, req_id: int, bar):
        """Handle historical data (bars)."""
        if req_id not in self.bar_data:
            self.bar_data[req_id] = []
        
        bar_data = BarData(
            symbol=f"REQ_{req_id}",
            timestamp=datetime.strptime(bar.date, "%Y%m%d %H:%M:%S") if " " in bar.date else datetime.strptime(bar.date, "%Y%m%d"),
            open=float(bar.open),
            high=float(bar.high),
            low=float(bar.low),
            close=float(bar.close),
            volume=int(bar.volume),
            average=float(bar.average),
            count=int(bar.count),
        )
        
        self.bar_data[req_id].append(bar_data)
        self.bar_queue.put((req_id, bar_data))
    
    def historicalDataEnd(self, req_id: int, start: str, end: str):
        """Called when historical data download is complete."""
        logger.info(f"Historical data complete for request {req_id}: {start} to {end}")
    
    def register_callback(self, event_type: str, callback: Callable):
        """Register a callback for an event type."""
        if event_type not in self.callbacks:
            self.callbacks[event_type] = []
        self.callbacks[event_type].append(callback)


class IBConnection:
    """
    Main Interactive Brokers connection manager.
    Handles connection lifecycle and data requests.
    """
    
    def __init__(self):
        if EClient is None:
            logger.warning("ibapi not installed. Using mock data mode.")
            self.client = None
            self.wrapper = None
            self.is_connected = False
            return
        
        self.wrapper = IBWrapper()
        self.client = EClient(self.wrapper)
        self.is_connected = False
        self.connection_thread: Optional[threading.Thread] = None
        self._request_id_counter = 1
    
    def connect(self) -> bool:
        """
        Establish connection to Interactive Brokers.
        
        Returns:
            True if connection successful, False otherwise
        """
        if self.client is None:
            logger.warning("ibapi not available. Skipping connection.")
            return False
        
        try:
            logger.info(f"Connecting to IB at {ib_config.host}:{ib_config.port}")
            self.client.connect(ib_config.host, ib_config.port, ib_config.client_id)
            
            # Start the client in a separate thread
            self.connection_thread = threading.Thread(target=self.client.run, daemon=True)
            self.connection_thread.start()
            
            # Wait for connection to establish
            max_retries = 10
            for i in range(max_retries):
                if self.wrapper.connection_status == "connected":
                    self.is_connected = True
                    logger.info("Connected to IB successfully")
                    return True
                time.sleep(0.5)
            
            logger.error("Connection timeout")
            return False
        
        except Exception as e:
            logger.error(f"Failed to connect to IB: {e}")
            return False
    
    def disconnect(self):
        """Disconnect from Interactive Brokers."""
        if self.client and self.is_connected:
            try:
                self.client.disconnect()
                self.is_connected = False
                logger.info("Disconnected from IB")
            except Exception as e:
                logger.error(f"Error during disconnect: {e}")
    
    def get_next_request_id(self) -> int:
        """Get the next available request ID."""
        req_id = self._request_id_counter
        self._request_id_counter += 1
        return req_id
    
    def request_market_data(self, symbol: str, exchange: str = "SMART") -> int:
        """
        Request real-time market data for a symbol.
        
        Args:
            symbol: Ticker symbol (e.g., "AAPL")
            exchange: Exchange (default: "SMART")
        
        Returns:
            Request ID for tracking the data
        """
        if not self.is_connected or self.client is None:
            logger.warning(f"Not connected. Cannot request market data for {symbol}")
            return -1
        
        try:
            req_id = self.get_next_request_id()
            contract = Contract()
            contract.symbol = symbol
            contract.secType = "STK"
            contract.exchange = exchange
            contract.currency = "USD"
            
            self.client.reqMktData(req_id, contract, "", False, False, [])
            logger.info(f"Requested market data for {symbol} (request ID: {req_id})")
            return req_id
        
        except Exception as e:
            logger.error(f"Error requesting market data: {e}")
            return -1
    
    def cancel_market_data(self, req_id: int):
        """Cancel market data subscription."""
        if self.client and self.is_connected:
            try:
                self.client.cancelMktData(req_id)
                logger.info(f"Cancelled market data for request {req_id}")
            except Exception as e:
                logger.error(f"Error cancelling market data: {e}")
    
    def request_historical_data(self, symbol: str, duration: str = "1 Y", bar_size: str = "1 day") -> int:
        """
        Request historical data for a symbol.
        
        Args:
            symbol: Ticker symbol
            duration: Duration string (e.g., "1 Y", "3 M", "1 D")
            bar_size: Bar size (e.g., "1 day", "1 hour", "5 mins")
        
        Returns:
            Request ID for tracking the data
        """
        if not self.is_connected or self.client is None:
            logger.warning(f"Not connected. Cannot request historical data for {symbol}")
            return -1
        
        try:
            req_id = self.get_next_request_id()
            contract = Contract()
            contract.symbol = symbol
            contract.secType = "STK"
            contract.exchange = "SMART"
            contract.currency = "USD"
            
            end_datetime = datetime.now().strftime("%Y%m%d %H:%M:%S")
            self.client.reqHistoricalData(req_id, contract, end_datetime, duration, bar_size, "TRADES", 1, 1, False, [])
            logger.info(f"Requested historical data for {symbol} (request ID: {req_id})")
            return req_id
        
        except Exception as e:
            logger.error(f"Error requesting historical data: {e}")
            return -1
    
    def get_tick_data(self, req_id: int) -> Optional[TickData]:
        """Get the latest tick data for a request ID."""
        return self.wrapper.tick_data.get(req_id)
    
    def get_bar_data(self, req_id: int) -> List[BarData]:
        """Get all bar data for a request ID."""
        return self.wrapper.bar_data.get(req_id, [])
    
    def register_callback(self, event_type: str, callback: Callable):
        """Register a callback for an event type."""
        if self.wrapper:
            self.wrapper.register_callback(event_type, callback)


# Global connection instance
_ib_connection: Optional[IBConnection] = None


def get_ib_connection() -> IBConnection:
    """Get or create the global IB connection instance."""
    global _ib_connection
    if _ib_connection is None:
        _ib_connection = IBConnection()
    return _ib_connection
