"""
Logging utility module for the Trading Intelligence System.
Provides centralized logging configuration and helper functions.
"""

import logging
import os
from pathlib import Path
from streamlit_app.config import logging_config


def setup_logger(name: str) -> logging.Logger:
    """
    Set up and return a configured logger instance.
    
    Args:
        name: Logger name (typically __name__)
    
    Returns:
        Configured logger instance
    """
    # Create logs directory if it doesn't exist
    log_dir = Path(logging_config.log_file).parent
    log_dir.mkdir(parents=True, exist_ok=True)
    
    logger = logging.getLogger(name)
    
    # Only configure if not already configured
    if not logger.handlers:
        logger.setLevel(getattr(logging, logging_config.log_level))
        
        # File handler
        file_handler = logging.FileHandler(logging_config.log_file)
        file_handler.setLevel(getattr(logging, logging_config.log_level))
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(getattr(logging, logging_config.log_level))
        
        # Formatter
        formatter = logging.Formatter(logging_config.log_format)
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        # Add handlers
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
    
    return logger


# Global logger instance
logger = setup_logger(__name__)
