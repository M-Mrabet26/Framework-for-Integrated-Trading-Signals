"""
Configuration module for the Trading Intelligence System.
Manages environment variables, API credentials, and system parameters.
"""

import os
from dotenv import load_dotenv
from dataclasses import dataclass
from typing import Optional

# Load environment variables from .env file
load_dotenv()


@dataclass
class IBConfig:
    """Interactive Brokers connection configuration."""
    host: str = os.getenv("IB_HOST", "127.0.0.1")
    port: int = int(os.getenv("IB_PORT", "7497"))  # 7497 for paper trading, 7496 for live
    client_id: int = int(os.getenv("IB_CLIENT_ID", "1"))
    account_id: Optional[str] = os.getenv("IB_ACCOUNT_ID", None)
    use_paper_trading: bool = os.getenv("IB_PAPER_TRADING", "true").lower() == "true"


@dataclass
class DataConfig:
    """Data pipeline configuration."""
    cache_dir: str = os.getenv("DATA_CACHE_DIR", "./data/cache")
    historical_days: int = int(os.getenv("HISTORICAL_DAYS", "252"))  # 1 year of trading days
    update_interval_seconds: int = int(os.getenv("UPDATE_INTERVAL", "60"))
    max_retries: int = int(os.getenv("MAX_RETRIES", "3"))


@dataclass
class ModelConfig:
    """Machine learning model configuration."""
    regime_model_type: str = os.getenv("REGIME_MODEL", "rule_based")  # rule_based, hmm, lstm
    sentiment_model_type: str = os.getenv("SENTIMENT_MODEL", "vader")  # vader, bert, transformer
    signal_combiner_type: str = os.getenv("SIGNAL_COMBINER", "conditional")  # conditional, gbm, dnn
    kelly_fraction: float = float(os.getenv("KELLY_FRACTION", "0.25"))  # Fractional Kelly for risk control
    min_confidence: float = float(os.getenv("MIN_CONFIDENCE", "0.6"))


@dataclass
class DashboardConfig:
    """Streamlit dashboard configuration."""
    page_config_layout: str = "wide"
    page_config_initial_sidebar_state: str = "expanded"
    theme: str = os.getenv("THEME", "dark")
    refresh_interval_seconds: int = int(os.getenv("DASHBOARD_REFRESH", "30"))


@dataclass
class LoggingConfig:
    """Logging configuration."""
    log_level: str = os.getenv("LOG_LEVEL", "INFO")
    log_file: str = os.getenv("LOG_FILE", "./logs/trading_system.log")
    log_format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"


# Global configuration instances
ib_config = IBConfig()
data_config = DataConfig()
model_config = ModelConfig()
dashboard_config = DashboardConfig()
logging_config = LoggingConfig()


def get_config_summary() -> dict:
    """Return a summary of all configurations."""
    return {
        "ib": {
            "host": ib_config.host,
            "port": ib_config.port,
            "paper_trading": ib_config.use_paper_trading,
        },
        "data": {
            "cache_dir": data_config.cache_dir,
            "historical_days": data_config.historical_days,
            "update_interval": data_config.update_interval_seconds,
        },
        "models": {
            "regime_model": model_config.regime_model_type,
            "sentiment_model": model_config.sentiment_model_type,
            "signal_combiner": model_config.signal_combiner_type,
            "kelly_fraction": model_config.kelly_fraction,
        },
    }
