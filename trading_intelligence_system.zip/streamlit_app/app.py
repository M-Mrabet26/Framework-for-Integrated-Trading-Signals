"""
Main Streamlit application for the Trading Intelligence System.
Multi-dashboard interface for algorithmic trading framework.
"""

import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import dashboard_config, get_config_summary
from core.state_manager import get_state_manager, MacroRegime, SentimentRegime
from core.ib_connection import get_ib_connection
from utils.logger import setup_logger

logger = setup_logger(__name__)


# Configure Streamlit page
st.set_page_config(
    page_title="Trading Intelligence System",
    page_icon="📈",
    layout=dashboard_config.page_config_layout,
    initial_sidebar_state=dashboard_config.page_config_initial_sidebar_state,
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main {
        padding: 0rem 1rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
    }
    .status-connected {
        color: #00ff00;
        font-weight: bold;
    }
    .status-disconnected {
        color: #ff0000;
        font-weight: bold;
    }
</style>
""", unsafe_allow_html=True)


def initialize_app():
    """Initialize the application and session state."""
    if "initialized" not in st.session_state:
        st.session_state.initialized = True
        st.session_state.state_manager = get_state_manager()
        st.session_state.ib_connection = get_ib_connection()
        logger.info("Application initialized")


def render_header():
    """Render the application header."""
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col1:
        st.title("📈 Trading Intelligence System")
        st.markdown("Multi-Signal Algorithmic Trading Framework")
    
    with col3:
        # Connection status
        state_manager = st.session_state.state_manager
        ib_connection = st.session_state.ib_connection
        
        if ib_connection.is_connected:
            st.markdown('<p class="status-connected">✓ IB Connected</p>', unsafe_allow_html=True)
        else:
            st.markdown('<p class="status-disconnected">✗ IB Disconnected</p>', unsafe_allow_html=True)


def render_sidebar():
    """Render the sidebar with navigation and controls."""
    with st.sidebar:
        st.header("⚙️ Configuration")
        
        # Dashboard selection
        page = st.radio(
            "Select Dashboard:",
            ["Overview", "Macro Analysis", "Fundamentals", "Sentiment", "Market Microstructure", "Trading Signal"],
            label_visibility="collapsed"
        )
        
        st.divider()
        
        # Ticker selection
        st.subheader("Market Selection")
        tickers_input = st.text_input(
            "Tickers (comma-separated):",
            value="AAPL,MSFT,GOOGL",
            help="Enter stock tickers to analyze"
        )
        
        if tickers_input:
            tickers = [t.strip().upper() for t in tickers_input.split(",")]
            st.session_state.state_manager.set_selected_tickers(tickers)
        
        st.divider()
        
        # Connection controls
        st.subheader("Interactive Brokers")
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🔗 Connect", use_container_width=True):
                with st.spinner("Connecting to IB..."):
                    ib_connection = st.session_state.ib_connection
                    if ib_connection.connect():
                        st.success("Connected to IB!")
                        st.session_state.state_manager.set_ib_connection_status(True)
                    else:
                        st.error("Failed to connect to IB")
        
        with col2:
            if st.button("🔌 Disconnect", use_container_width=True):
                ib_connection = st.session_state.ib_connection
                ib_connection.disconnect()
                st.session_state.state_manager.set_ib_connection_status(False)
                st.info("Disconnected from IB")
        
        st.divider()
        
        # System info
        st.subheader("System Info")
        config_summary = get_config_summary()
        st.json(config_summary)
        
        return page


def render_overview():
    """Render the overview dashboard."""
    st.header("📊 System Overview")
    
    state_manager = st.session_state.state_manager
    summary = state_manager.get_summary()
    
    # Key metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "Macro Regime",
            summary["macro"]["regime"],
            f"{summary['macro']['confidence']:.1%}"
        )
    
    with col2:
        st.metric(
            "Sentiment Regime",
            summary["sentiment"]["regime"],
            f"{summary['sentiment']['confidence']:.1%}"
        )
    
    with col3:
        st.metric(
            "Trading Signal",
            f"{summary['signal']['final_signal']:.2f}",
            f"Confidence: {summary['signal']['confidence']:.1%}"
        )
    
    with col4:
        st.metric(
            "Position Size",
            f"{summary['signal']['position_size']:.1%}",
            "Kelly Criterion"
        )
    
    st.divider()
    
    # Signal breakdown
    st.subheader("Signal Breakdown")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### Macro Analysis")
        st.write(f"**Regime:** {summary['macro']['regime']}")
        st.write(f"**Volatility:** {summary['macro']['volatility']:.2f}")
        st.write(f"**Confidence:** {summary['macro']['confidence']:.1%}")
    
    with col2:
        st.markdown("### Sentiment Analysis")
        st.write(f"**Regime:** {summary['sentiment']['regime']}")
        st.write(f"**Score:** {summary['sentiment']['score']:.2f}")
        st.write(f"**Confidence:** {summary['sentiment']['confidence']:.1%}")
    
    st.divider()
    
    # Selected tickers
    st.subheader("Selected Tickers")
    if summary["selected_tickers"]:
        ticker_cols = st.columns(len(summary["selected_tickers"]))
        for i, ticker in enumerate(summary["selected_tickers"]):
            with ticker_cols[i]:
                st.metric(ticker, "—", "Monitoring")
    else:
        st.info("No tickers selected. Configure in the sidebar.")


def render_macro_dashboard():
    """Render the Macro Analysis dashboard."""
    st.header("🌍 Macro Analysis Dashboard")
    
    state_manager = st.session_state.state_manager
    macro_state = state_manager.macro_state
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Interest Rate", f"{macro_state.interest_rate:.2f}%")
    
    with col2:
        st.metric("Yield Curve Slope", f"{macro_state.yield_curve_slope:.2f}%")
    
    with col3:
        st.metric("Inflation Rate", f"{macro_state.inflation_rate:.2f}%")
    
    with col4:
        st.metric("VIX", f"{macro_state.volatility_index:.2f}")
    
    st.divider()
    
    st.subheader("Regime Classification")
    col1, col2 = st.columns(2)
    
    with col1:
        st.write(f"**Current Regime:** {macro_state.regime.value}")
        st.write(f"**Confidence:** {macro_state.confidence:.1%}")
    
    with col2:
        st.write(f"**Liquidity Score:** {macro_state.liquidity_score:.2f}")
        st.write(f"**Last Updated:** {macro_state.last_updated.strftime('%Y-%m-%d %H:%M:%S')}")
    
    st.divider()
    
    # Mock data for demonstration
    st.subheader("Historical Macro Indicators")
    
    dates = pd.date_range(end=datetime.now(), periods=30, freq='D')
    data = pd.DataFrame({
        'Date': dates,
        'Interest Rate': [2.5 + i*0.05 for i in range(30)],
        'Inflation': [3.0 + i*0.02 for i in range(30)],
        'VIX': [15 + (i % 10) for i in range(30)],
    })
    
    st.line_chart(data.set_index('Date'))


def render_fundamental_dashboard():
    """Render the Fundamental Analysis dashboard."""
    st.header("💼 Corporate & Fundamental Dashboard")
    
    state_manager = st.session_state.state_manager
    fundamental_state = state_manager.fundamental_state
    
    st.subheader("Fundamental Factor Scores")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Value Score", f"{fundamental_state.value_score:.2f}")
    
    with col2:
        st.metric("Quality Score", f"{fundamental_state.quality_score:.2f}")
    
    with col3:
        st.metric("Growth Score", f"{fundamental_state.growth_score:.2f}")
    
    st.divider()
    
    st.subheader("Company Metrics")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Market Cap", f"${fundamental_state.market_cap/1e9:.2f}B")
    
    with col2:
        st.metric("P/E Ratio", f"{fundamental_state.price_to_earnings:.2f}")
    
    with col3:
        st.metric("EPS", f"${fundamental_state.earnings_per_share:.2f}")
    
    st.divider()
    
    # Factor scores visualization
    st.subheader("Factor Scores Comparison")
    
    factors_data = pd.DataFrame({
        'Factor': ['Value', 'Quality', 'Growth'],
        'Score': [
            fundamental_state.value_score,
            fundamental_state.quality_score,
            fundamental_state.growth_score
        ]
    })
    
    st.bar_chart(factors_data.set_index('Factor'))


def render_sentiment_dashboard():
    """Render the Sentiment Analysis dashboard."""
    st.header("📰 News & NLP Sentiment Dashboard")
    
    state_manager = st.session_state.state_manager
    sentiment_state = state_manager.sentiment_state
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Overall Sentiment", f"{sentiment_state.overall_score:.2f}")
    
    with col2:
        st.metric("News Sentiment", f"{sentiment_state.news_sentiment:.2f}")
    
    with col3:
        st.metric("Social Sentiment", f"{sentiment_state.social_sentiment:.2f}")
    
    st.divider()
    
    st.subheader("Sentiment Regime")
    col1, col2 = st.columns(2)
    
    with col1:
        st.write(f"**Regime:** {sentiment_state.regime.value}")
    
    with col2:
        st.write(f"**Confidence:** {sentiment_state.confidence:.1%}")
    
    st.divider()
    
    st.subheader("Entity Sentiment Scores")
    
    if sentiment_state.entity_scores:
        entity_df = pd.DataFrame(
            list(sentiment_state.entity_scores.items()),
            columns=['Entity', 'Sentiment Score']
        ).sort_values('Sentiment Score', ascending=False)
        
        st.bar_chart(entity_df.set_index('Entity'))
    else:
        st.info("No entity sentiment data available yet.")


def render_microstructure_dashboard():
    """Render the Market Microstructure dashboard."""
    st.header("📊 Pattern Recognition & Market Microstructure Dashboard")
    
    state_manager = st.session_state.state_manager
    micro_state = state_manager.micro_state
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("RSI", f"{micro_state.rsi:.2f}")
    
    with col2:
        st.metric("Volatility", f"{micro_state.volatility:.2f}%")
    
    with col3:
        st.metric("Trading Mode", micro_state.trading_mode.value)
    
    with col4:
        st.metric("Confidence", f"{micro_state.confidence:.1%}")
    
    st.divider()
    
    st.subheader("Technical Signals")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Momentum Signal", f"{micro_state.momentum_signal:.2f}")
    
    with col2:
        st.metric("Mean Reversion", f"{micro_state.mean_reversion_signal:.2f}")
    
    with col3:
        st.metric("Breakout Signal", f"{micro_state.breakout_signal:.2f}")
    
    st.divider()
    
    # Moving averages
    st.subheader("Moving Averages")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.metric("MA(20)", f"{micro_state.moving_average_20:.2f}")
    
    with col2:
        st.metric("MA(50)", f"{micro_state.moving_average_50:.2f}")


def render_signal_dashboard():
    """Render the Trading Signal dashboard."""
    st.header("🎯 Trading Signal & Position Sizing")
    
    state_manager = st.session_state.state_manager
    signal_state = state_manager.signal_state
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Final Signal", f"{signal_state.final_signal:.3f}", "[-1, 1]")
    
    with col2:
        st.metric("Signal Confidence", f"{signal_state.signal_confidence:.1%}")
    
    with col3:
        st.metric("Position Size", f"{signal_state.recommended_position_size:.1%}", "Kelly Criterion")
    
    st.divider()
    
    st.subheader("Kelly Criterion Inputs")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Win Probability", f"{signal_state.win_probability:.1%}")
    
    with col2:
        st.metric("Payoff Ratio", f"{signal_state.payoff_ratio:.2f}")
    
    with col3:
        st.metric("Kelly Fraction", f"{signal_state.kelly_fraction:.1%}")
    
    st.divider()
    
    st.subheader("Signal Interpretation")
    
    if signal_state.final_signal > 0.5:
        st.success("🟢 Strong Buy Signal")
    elif signal_state.final_signal > 0.2:
        st.info("🟡 Moderate Buy Signal")
    elif signal_state.final_signal < -0.5:
        st.error("🔴 Strong Sell Signal")
    elif signal_state.final_signal < -0.2:
        st.warning("🟠 Moderate Sell Signal")
    else:
        st.info("⚪ Neutral Signal")


def main():
    """Main application entry point."""
    initialize_app()
    
    render_header()
    
    page = render_sidebar()
    
    # Route to the selected dashboard
    if page == "Overview":
        render_overview()
    elif page == "Macro Analysis":
        render_macro_dashboard()
    elif page == "Fundamentals":
        render_fundamental_dashboard()
    elif page == "Sentiment":
        render_sentiment_dashboard()
    elif page == "Market Microstructure":
        render_microstructure_dashboard()
    elif page == "Trading Signal":
        render_signal_dashboard()


if __name__ == "__main__":
    main()
